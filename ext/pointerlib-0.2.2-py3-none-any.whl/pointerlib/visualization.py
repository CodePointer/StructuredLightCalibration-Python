# -*- coding: utf-8 -*-

# @Time:      2022/2/28 13:15
# @Author:    qiao
# @Email:     rukunqiao@outlook.com
# @File:      visualization.py
# @Software:  PyCharm
# @Description:
#   None

# - Package Imports - #
import numpy as np
import time
import open3d as o3d
import pointerlib as plb
import cv2
from collections import Iterable


# - Coding Part - #
def imviz_loop(img_list, name='DEFAULT', interval=100, normalize=None, idx_start=0, loop=True):
    """Show images in loop. Press Esc to exit."""
    img_u8_list = []
    for i in range(len(img_list)):
        img = img_list[i].copy()
        img_copy = plb.t2a(img)
        if isinstance(normalize, list):
            min_val, max_val = 0, 255
            if len(normalize) == 0:
                min_val, max_val = np.min(img_copy), np.max(img_copy)
            elif len(normalize) == 2:
                min_val, max_val = normalize
            else:
                raise ValueError(f"Normalize length is not valid: {len(normalize)}")
            img_copy = (img_copy.astype(np.float32) - min_val) / (max_val - min_val)
            img_copy = np.clip(img_copy, 0.0, 1.0)
        if img_copy.dtype == np.float32:
            img_copy = (img_copy * 255.0).astype(np.uint8)
        img_u8 = img_copy
        if idx_start >= 0:
            img_u8 = cv2.putText(img_u8, str(i + idx_start), (20, 40), cv2.FONT_HERSHEY_SIMPLEX,
                                 1, (0, 0, 255), 2)
        img_u8_list.append(img_u8)

    key = None
    idx = 0
    # cv2.namedWindow(name)
    while key not in [27, 13]:  # 'esc', 'enter'
        idx = idx if idx < len(img_list) else 0
        cv2.imshow(name, img_u8_list[idx])
        key = cv2.waitKey(interval)
        idx += 1
        if idx == len(img_list) and not loop:
            break
    # cv2.destroyWindow(name)
    return key


class DisparityMapVisual:

    def __init__(self, hei, wid, left_intrin, baseline, disp_range):
        self.left_intrin = left_intrin
        self.hei = hei
        self.wid = wid
        self.baseline = baseline
        self.disp_min, self.disp_max = disp_range
        self.proj_transformer = plb.ProjectiveTransformer(left_intrin, (hei, wid))

        self.visualizer = o3d.visualization.Visualizer()
        self.inf_pinhole = o3d.camera.PinholeCameraIntrinsic(width=wid, height=hei,
                                                             fx=left_intrin[0, 0], fy=left_intrin[1, 1],
                                                             cx=left_intrin[0, 2], cy=left_intrin[1, 2])

        self.pos_list = None

    def set_pos_list(self, pos_list):
        self.pos_list = pos_list

    def run(self, disp_list, img_list, win_name, save_func=None):
        if self.pos_list is None:
            self.pos_list = plb.PosManager()

        self.visualizer.create_window(width=self.wid, height=self.hei, window_name=win_name)
        self.visualizer.get_render_option().point_size = 1.0

        frm_num = len(disp_list)
        for frm_idx in range(frm_num):
            # disp_set = disp_list[frm_idx][disp_list[frm_idx] > 0]
            # disp_min, disp_max = np.percentile(disp_set, [1.0, 99.0])
            disp_min, disp_max = self.disp_min, self.disp_max
            mask = (disp_list[frm_idx] > disp_min) * (disp_list[frm_idx] < disp_max)
            xyz = self.proj_transformer.disp2point(disp_list[frm_idx], self.baseline, mask)
            pos = self.pos_list[frm_idx] if isinstance(self.pos_list, list) else self.pos_list
            xyz_ref = xyz
            # xyz_ref = plb.point_transform(xyz, pos.get_3x4mat(), flag_reverse=True)
            pcd = o3d.geometry.PointCloud()
            pcd.points = o3d.utility.Vector3dVector(xyz_ref)
            # color_ref = img_list[frm_idx][mask == 1.0].reshape(-1, 1).repeat(3, axis=1).astype(np.float64)
            color_ref = np.ones_like(xyz_ref) * 0.5
            pcd.colors = o3d.utility.Vector3dVector(color_ref)
            pcd.estimate_normals()
            pcd = pcd.voxel_down_sample(voxel_size=0.5)
            # o3d.visualization.draw_geometries([pcd])

            # radii = [0.0005, 0.001, 0.002, 0.004]
            # radii = np.array([4.0, 8.0, 16.0, 32.0, 64.0])
            # print('Begin.')
            # rec_mesh = o3d.geometry.TriangleMesh.create_from_point_cloud_ball_pivoting(
            #     pcd, o3d.utility.DoubleVector(radii))
            # print('End.')
            # o3d.visualization.draw_geometries([rec_mesh])

            self.visualizer.clear_geometries()
            self.visualizer.add_geometry(pcd)
            time.sleep(0.01)

            camera = o3d.camera.PinholeCameraParameters()
            camera.intrinsic = self.inf_pinhole
            camera.extrinsic = pos.get_4x4mat()
            ctr = self.visualizer.get_view_control()
            ctr.convert_from_pinhole_camera_parameters(camera, allow_arbitrary=True)

            self.visualizer.poll_events()
            self.visualizer.update_renderer()
            time.sleep(0.01)

            # Save
            if save_func is not None:
                image = self.visualizer.capture_screen_float_buffer(do_render=False)
                img_u8 = (np.asarray(image) * 255).astype(np.uint8)
                img_u8 = cv2.cvtColor(img_u8, cv2.COLOR_RGB2BGR)
                save_func(img_u8, frm_idx)
            # self.visualizer.run()

        # self.visualizer.run()
        # self.visualizer.destroy_window()
        pass


class BlobVisual:

    def __init__(self, hei=480, wid=848, scale=2.0, color_map=cv2.COLORMAP_JET):

        self.img_hei = hei
        self.img_wid = wid

        tmp_color_list = np.arange(0, 255).astype(np.uint8)
        color_list = cv2.applyColorMap(tmp_color_list, color_map)
        self.color_list = [x.reshape(-1).tolist() for x in color_list]

        self.scale = scale
        self.edge_color = [192, 192, 192]

    def _up(self, *args):
        if len(args) == 1:
            return args[0] * self.scale
        else:
            return tuple(x * int(self.scale) for x in args)

    def _pt(self, pair, scale=True):
        if scale:
            return int(pair[0] * self.scale), int(pair[1] * self.scale)
        else:
            return int(pair[0]), int(pair[1])

    def _color(self, i):
        if isinstance(i, int):
            idx = np.mod(i * 13, 255)
        elif isinstance(i, float):
            idx = int(i * 254.0)
        else:
            return None
        return self.color_list[idx]

    def __call__(self, pos, mask, value=None, edge=None, color=None, img_back=None):
        """ignore 0 pt"""
        if img_back is None:
            img_back = np.zeros([self.img_hei, self.img_wid, 3], dtype=np.uint8)
        else:
            img_back = (plb.t2a(img_back) * 255).astype(np.uint8)
            self.img_hei, self.img_wid = img_back.shape[:2]
            img_back = cv2.cvtColor(img_back, cv2.COLOR_GRAY2RGB)

        my_canva = cv2.resize(img_back, self._up(self.img_wid, self.img_hei), interpolation=cv2.INTER_NEAREST)

        pos = pos.squeeze()
        mask = mask.squeeze()
        value = None if value is None else value.squeeze()
        edge = None if edge is None else edge.squeeze().long()

        blob_num = pos.shape[0]

        # Edge
        if edge is not None:
            for i in range(1, blob_num):
                if mask[i] == 0:
                    continue
                for j in edge[i]:
                    if mask[j] == 0:
                        continue
                    if j > 0 and i < j:  # is edge
                        cv2.line(my_canva, self._pt(pos[i]), self._pt(pos[j]), self.edge_color, 1)

        # Dot
        for i in range(1, blob_num):
            if mask[i] == 0:
                continue
            color = self._color(i) if value is None else self._color(value[i].item())
            cv2.circle(my_canva, self._pt(pos[i]), 2, color, -1)

        return my_canva

    # def run(self, pos, mask, value=None, edge=None, color=None, img_back=None):
    #     """ignore 0 pt"""
    #     if img_back is None:
    #         img_back = np.zeros([self.img_hei, self.img_wid, 3], dtype=np.uint8)
    #     else:
    #         img_back = (plb.t2a(img_back) * 255).astype(np.uint8)
    #         self.img_hei, self.img_wid = img_back.shape[:2]
    #         img_back = cv2.cvtColor(img_back, cv2.COLOR_GRAY2RGB)
    #
    #     my_canva = cv2.resize(img_back, self._up(self.img_wid, self.img_hei), interpolation=cv2.INTER_NEAREST)
    #
    #     pos = pos.squeeze()
    #     mask = mask.squeeze()
    #     value = None if value is None else value.squeeze()
    #     edge = None if edge is None else edge.squeeze().long()
    #
    #     blob_num = pos.shape[0]
    #
    #     # Edge
    #     if edge is not None:
    #         for i in range(1, blob_num):
    #             if mask[i] == 0:
    #                 continue
    #             for j in edge[i]:
    #                 if mask[j] == 0:
    #                     continue
    #                 if j > 0 and i < j:  # is edge
    #                     cv2.line(my_canva, self._pt(pos[i]), self._pt(pos[j]), self.edge_color, 1)
    #
    #     # Dot
    #     for i in range(1, blob_num):
    #         if mask[i] == 0:
    #             continue
    #         color = self._color(i) if value is None else self._color(value[i].item())
    #         cv2.circle(my_canva, self._pt(pos[i]), 2, color, -1)
    #
    #     return my_canva