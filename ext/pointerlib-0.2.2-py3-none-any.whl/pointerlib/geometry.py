# -*- coding: utf-8 -*-

# @Time:      2021/2/25 15:02
# @Author:    qiao
# @Email:     rukunqiao@outlook.com
# @File:      geometry.py
# @Software:  PyCharm
# @Description:
#   None

# - Package Imports - #
import torch
import numpy as np
from scipy.spatial.transform import Rotation
from scipy.optimize import leastsq

from .dataio import a2t


# - Coding Part - #
class ProjectiveTransformer:
    def __init__(self, intrin_mat, img_size):
        self.fx = intrin_mat[0, 0]
        self.fy = intrin_mat[1, 1]
        self.dx = intrin_mat[0, 2]
        self.dy = intrin_mat[1, 2]
        self.f = (self.fx + self.fy) / 2.0
        self.hei, self.wid = img_size

        self.ww = np.arange(0, self.wid).reshape(1, -1).repeat(self.hei, axis=0)
        self.hh = np.arange(0, self.hei).reshape(-1, 1).repeat(self.wid, axis=1)

    def depth2point(self, depth_map, mask=None):
        assert len(depth_map.shape) == 2
        zz = depth_map.copy()
        xx = (self.ww - self.dx) / self.fx * zz
        yy = (self.hh - self.dy) / self.fy * zz
        if mask is not None:
            zz = zz[mask].reshape(-1, 1)
            xx = xx[mask].reshape(-1, 1)
            yy = yy[mask].reshape(-1, 1)
        points = np.concatenate([xx, yy, zz], axis=1)
        return points

    def point2depth(self, points):
        assert len(points.shape) == 3
        return points[:, :, 2].copy()

    def disp2point(self, disp_map, baseline, mask=None):
        assert len(disp_map.shape) == 2
        fb = baseline * (self.fx + self.fy) / 2
        dd = disp_map.copy()
        mask_valid = (dd > 0).astype(np.float32)
        dd[mask_valid == 0] = 1.0
        zz = fb / dd
        zz[mask_valid == 0] = 0.0
        return self.depth2point(zz, mask)


def line_regression(xyz_sets):
    """
    Only used in 3D space.
        xyz_sets: [N, 3]
        cite: http://www.whudj.cn/?p=72
    """
    if not isinstance(xyz_sets, list):
        xyz_sets = [xyz_sets]
    xyz = np.concatenate(xyz_sets, axis=0)
    p1 = xyz.mean(axis=0)  # Center point

    xyz_norm = xyz - p1
    S1 = (xyz_norm ** 2).sum() * np.eye(3)
    S2 = xyz_norm.T.dot(xyz_norm)
    S = S1 - S2
    vals, vecs = np.linalg.eig(S)
    v = vecs[:, np.argmin(vals)]

    err_vec = (xyz_norm ** 2).sum(axis=1) - xyz_norm.dot(v) ** 2
    err = err_vec.mean()

    return p1, v, err


def plane_regression(xyz_sets):
    """
    Both in 2D and 3D set.
    :param xyz_sets: [N, d], d = 2/3
    :return:
    """
    if not isinstance(xyz_sets, list):
        xyz_sets = [xyz_sets]
    dim = xyz_sets[0].shape[1]

    A = np.zeros((dim, dim), dtype=np.float64)
    b = np.zeros((dim, 1), dtype=np.float64)
    for xyz_set in xyz_sets:
        A += xyz_set.T.dot(xyz_set)
        b += xyz_set.T.dot(np.ones([xyz_set.shape[0], 1], dtype=np.float64))

    x = np.linalg.inv(A).dot(b)
    errs = []
    for xyz_set in xyz_sets:
        err_vec = xyz_set.dot(x) - np.ones([xyz_set.shape[0], 1], dtype=np.float64)
        errs.append(np.sqrt((err_vec * err_vec).mean()))

    return x, errs


def transform_back(mat3x4):
    rot_ = mat3x4[:, :3].T
    trans_ = - rot_.dot(mat3x4[:, 3:])
    return np.concatenate([rot_, trans_], axis=1)


def _transform_back(mat3x4):
    rot_ = mat3x4[:, :3].T
    trans_ = - rot_.dot(mat3x4[:, 3:])
    return np.concatenate([rot_, trans_], axis=1)


# def _transform_back2(mat3x4):
#     rot, trans = np.split(mat3x4, [3], axis=1)
#     rot_ = rot.T
#     trans_ = - rot.dot(trans)
#     return np.concatenate([rot_, trans_], axis=1)
#
#
# def point_transform2(pt, mat3x4, flag_reverse=False):
#     mat3x4 = _transform_back2(mat3x4) if flag_reverse else mat3x4
#     rot, trans = np.split(mat3x4, [3], axis=1)
#     pt_ = rot.dot((pt + trans.reshape(-1)).T).T
#     return pt_


def point_transform(pt, mat3x4, flag_reverse=False):
    """pt: [N, 3] or [3, ]"""
    mat3x4 = _transform_back(mat3x4) if flag_reverse else mat3x4
    rot, trans = np.split(mat3x4, [3], axis=1)
    pt_ = rot.dot(pt.T).T + trans.reshape(-1)
    return pt_


def plane_transform(abc, mat3x4, flag_reverse=False):
    """abc = [3]"""
    mat3x4 = _transform_back(mat3x4) if flag_reverse else mat3x4
    a, b, c = abc
    n = abc.reshape(-1)
    p = np.zeros_like(n)
    p[2] = 1 / c
    n_ = point_transform(n, mat3x4)
    p_ = point_transform(p, mat3x4)
    abc_ = n_ / n_.dot(p_)
    return abc_


# def plane_transform2(abc, mat3x4, flag_reverse=False):
#     mat3x4 = _transform_back(mat3x4) if flag_reverse else mat3x4
#     a, b, c = abc
#     n = abc.reshape(-1)
#     p = np.zeros_like(n)
#     p[2] = 1 / c
#     n_ = point_transform2(n, mat3x4)
#     p_ = point_transform2(p, mat3x4)
#     abc_ = n_ / n_.dot(p_)
#     return abc_


class DepthMapVisual:
    def __init__(self, depth_map, focus, mask=None):
        """
        depth_map: [1, H, W], torch.Tensor or numpy.Array.
        focus: float
        """
        self.depth_map = a2t(depth_map)
        self.imsize = depth_map.shape[-2:]
        self.focus = focus
        self.mask = mask if mask is not None else torch.ones_like(self.depth_map)

        hei, wid = self.imsize
        self.dx = wid // 2
        self.dy = hei // 2

    def to_xyz_mat(self):
        hei, wid = self.imsize
        hh = torch.arange(0, hei).view(-1, 1).repeat(1, wid).unsqueeze(0)  # [1, H, W]
        ww = torch.arange(0, wid).view(1, -1).repeat(hei, 1).unsqueeze(0)  # [1, H, W]
        xyz_mat = torch.cat([
            (ww - self.dx) / self.focus,
            (hh - self.dy) / self.focus,
            torch.ones_like(self.depth_map)
        ], dim=0) * self.depth_map
        return xyz_mat

    def to_xyz_set(self):
        xyz_mat = self.to_xyz_mat()
        xyz_set = xyz_mat.reshape(3, -1).permute(1, 0)
        return xyz_set

    def to_mesh(self):
        vertices = self.to_xyz_set().unsqueeze(0)
        hei, wid = self.imsize
        faces = []
        for h in range(0, hei - 1):
            for w in range(0, wid - 1):
                lf_up = h * wid + w
                lf_dn = (h + 1) * wid + w
                rt_up = h * wid + w + 1
                rt_dn = (h + 1) * wid + w + 1
                triangles = torch.as_tensor([
                    [lf_up, rt_dn, rt_up],
                    [lf_up, lf_dn, rt_dn]
                ], dtype=torch.int)  # [2, 3]
                faces.append(triangles)
        faces = torch.cat(faces, dim=0).unsqueeze(0)
        return vertices, faces


class PosManager:
    def __init__(self):
        self.trans = np.array([0.0, 0.0, 0.0], np.float64)
        self.rot = Rotation.from_matrix(np.eye(3))

    def set_trans(self, trans):
        self.trans = trans

    def set_rot(self, **kwargs):
        if 'mat' in kwargs:
            self.rot = Rotation.from_matrix(kwargs['mat'])
        elif 'quat' in kwargs:
            self.rot = Rotation.from_quat(kwargs['quat'])
        elif 'eular' in kwargs:
            self.rot = Rotation.from_euler(*kwargs['eular'])

    def set_from_xyz(self, xyz_frm, xyz_ref):
        """
        xyz1 & xyz2 are corresponded points
            cite: https://zhuanlan.zhihu.com/p/111322916
        """
        c_frm = xyz_frm.mean(axis=0)
        c_ref = xyz_ref.mean(axis=0)

        xyz_frm_norm = xyz_frm - c_frm
        xyz_ref_norm = xyz_ref - c_ref

        W = xyz_frm_norm.T.dot(xyz_ref_norm)
        U, S, V = np.linalg.svd(W)
        refine_mat = np.eye(3)
        refine_mat[2, 2] = np.linalg.det(U) * np.linalg.det(V)
        rot = U.dot(refine_mat).dot(V)

        self.rot = Rotation.from_matrix(rot)
        self.trans = c_frm - rot.dot(c_ref)

    def set_from_look(self, pos, look, up):
        self.trans = pos
        z_vec = - look / np.linalg.norm(look)
        x_vec = - up / np.linalg.norm(up)
        y_vec = np.cross(z_vec, x_vec)
        rot_mat = np.stack([x_vec, y_vec, z_vec], axis=1)
        self.rot = Rotation.from_matrix(rot_mat)

    def get_trans(self):
        return self.trans.reshape(3, 1)

    def get_3x3mat(self):
        return self.rot.as_matrix()

    def get_quat(self):
        return self.rot.as_quat()

    def get_3x4mat(self):
        return np.concatenate([self.rot.as_matrix(), self.trans.reshape(3, 1)], axis=1)

    def get_4x4mat(self):
        return np.concatenate([self.get_3x4mat(), np.array([0, 0, 0, 1], dtype=np.float64).reshape(1, 4)], axis=0)

    def get_7vec(self):
        return np.concatenate([self.rot.as_quat(), self.trans], axis=0)


# For two device warping
class CoordCompute:
    def __init__(self, cam_size, cam_intrin, pat_intrin, ext_rot, ext_tran):
        """
            cam_size: [wid, hei]
            pat_size: [wid, hei]
            cam_intrin: [fx, fy, dx, dy]
            pat_intrin: [fx, fy, dx, dy]
            ext_rot: 3x3 matrix, numpy.Array
            ext_tran: 3 matrix, numpy.Array
        """
        self.cam_size = cam_size
        wid, hei = self.cam_size
        fx, fy, dx, dy = cam_intrin
        ww = np.arange(0, wid).reshape(1, -1).repeat(hei, axis=0)  # [hei, wid]
        hh = np.arange(0, hei).reshape(-1, 1).repeat(wid, axis=1)  # [hei, wid]
        vec_mat = np.stack([
            (ww - dx) / fx,
            (hh - dy) / fy,
            np.ones_like(ww),
        ], axis=2)
        vec_mat = vec_mat.reshape([hei, wid, 3, 1])

        self.abc_mat = np.matmul(ext_rot, vec_mat).reshape([hei, wid, 3])  # [hei, wid, 3]
        self.abc_mat = a2t(self.abc_mat.astype(np.float32))  # [3, hei, wid]
        self.ext_tran = a2t(ext_tran)
        self.pat_intrin = a2t(pat_intrin)

    def __call__(self, depth):
        denominator = self.abc_mat[2] * depth + self.ext_tran[2]
        xx = (self.abc_mat[0] * depth + self.ext_tran[0]) / denominator
        yy = (self.abc_mat[1] * depth + self.ext_tran[1]) / denominator
        fu, fv, du, dv = self.pat_intrin
        uu = fu * xx + du
        vv = fv * yy + dv
        return uu, vv


class WarpLayer2D(torch.nn.Module):
    """Warping based on torch.grid_sample"""
    def __init__(self):
        super().__init__()
        pass

    def forward(self, uu_mat, vv_mat, src_mat, mask_flag=False):
        """src_mat: [... H, W]"""
        dst_hei, dst_wid = uu_mat.shape[-2:]
        src_hei, src_wid = src_mat.shape[-2:]
        src_mat = src_mat.reshape(-1, 1, src_hei, src_wid)
        batch = src_mat.shape[0]

        xx_grid = uu_mat.view(1, dst_hei, dst_wid, 1)
        yy_grid = vv_mat.view(1, dst_hei, dst_wid, 1)
        xx_grid = 2.0 * xx_grid / (src_wid - 1) - 1.0
        yy_grid = 2.0 * yy_grid / (src_hei - 1) - 1.0
        xy_grid = torch.cat([xx_grid, yy_grid], dim=3).expand(batch, dst_hei, dst_wid, 2)

        warped_mat = torch.nn.functional.grid_sample(src_mat, xy_grid, padding_mode='border', align_corners=False)
        if mask_flag:
            mask = torch.nn.functional.grid_sample(torch.ones_like(src_mat), xy_grid,
                                                   padding_mode='zeros', align_corners=False)
            mask[mask > 0.99] = 1.0
            mask[mask < 1.0] = 0.0
            warped_mat *= mask
        return warped_mat
