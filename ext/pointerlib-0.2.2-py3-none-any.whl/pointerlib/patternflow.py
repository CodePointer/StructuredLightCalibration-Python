# -*- coding: utf-8 -*-

# @Time:      2021/2/25 21:21
# @Author:    qiao
# @Email:     rukunqiao@outlook.com
# @File:      patternflow.py
# @Software:  PyCharm
# @Description:
#   None

# - Package Imports - #
import torch
import torch.nn.functional as F
import cv2
import numpy as np
from pathlib import Path
from collections import deque
from pointerlib.dataio import t2a, a2t, imload


# - Coding Part - #
class ConIdGenerator:
    def __init__(self, start_id=42):
        self._start_id = start_id
        self.next_id = start_id + 1

    def reset(self):
        self.next_id = self._start_id + 1

    def get_new(self, length=1):
        next_ids = list(range(self.next_id, self.next_id + length))
        self.next_id += length
        if length == 1:
            return next_ids[0]
        else:
            return next_ids

    def get_new_tensor(self, length=1):
        res = self.get_new(length)
        if length == 1:
            res = [res]
        return torch.Tensor(res).long()


class BlobFlowEstimator:
    def __init__(self, max_frm, imsize):
        self.max_frm = max_frm
        self.hei, self.wid = imsize

        # Create blob detector
        blob_params = cv2.SimpleBlobDetector_Params()
        blob_params.minThreshold = 10
        blob_params.maxThreshold = 200
        blob_params.thresholdStep = 10
        blob_params.filterByCircularity = False
        blob_params.filterByConvexity = False
        blob_params.filterByInertia = False
        blob_params.filterByArea = True
        blob_params.minArea = 0
        blob_params.maxArea = 20
        blob_params.filterByColor = True
        blob_params.blobColor = 255
        blob_params.minDistBetweenBlobs = 0
        self.blob_detector = cv2.SimpleBlobDetector_create(blob_params)

        # Set label & mat for further tracking
        self.label_mat = None
        self.label2idx = None
        self.points = []        # Set of key points
        self.valid_tag = []

    def set_first(self, img):
        blobs = self.blob_detector.detect(img)
        self._update_distance_field(blobs)
        self.points.clear()
        for key_point in blobs:
            self.points.append(deque([key_point.pt]))
        return self.points

    def _update_distance_field(self, blobs):
        # Create binary img
        bin_img = np.ones([self.hei, self.wid], dtype=np.uint8) * 255
        for key_point in blobs:
            x, y = key_point.pt
            w = min(round(x), self.wid - 1)
            h = min(round(y), self.hei - 1)
            bin_img[h, w] = 0

        # Create distanceTransformImage with Label
        _, self.label_mat = cv2.distanceTransformWithLabels(bin_img, cv2.DIST_L1, 3,
                                                                   labelType=cv2.DIST_LABEL_PIXEL)

        # Create match_label
        self.label2idx = np.zeros(len(blobs) + 1, dtype=np.int32)
        for i, key_point in enumerate(blobs):
            x, y = key_point.pt
            w = min(round(x), self.wid - 1)
            h = min(round(y), self.hei - 1)
            label = self.label_mat[h, w]
            self.label2idx[label] = i

    def set_next(self, img):
        blobs = self.blob_detector.detect(img)
        self._update_distance_field(blobs)
        self._match_keypoints(blobs)
        return self.points

    def _match_keypoints(self, blobs):
        new_points = []
        for now_point in blobs:
            new_points.append(deque([now_point.pt]))
        for last_point in self.points:
            if len(last_point) == 0:
                continue
            x, y = last_point[0]
            w = min(round(x), self.wid - 1)
            h = min(round(y), self.hei - 1)
            idx = self.label2idx[self.label_mat[h, w]]
            if len(new_points[idx]) > 1:
                continue
            last_point.appendleft(new_points[idx][0])
            new_points[idx] = last_point
            if len(new_points[idx]) > self.max_frm:
                new_points[idx].pop()
        self.points = new_points

    def check_outlier(self, checker=lambda x: True):
        self.valid_tag.clear()
        for trajectory in self.points:
            self.valid_tag.append(checker(trajectory))
        return self.valid_tag

    def clear_outlier(self):
        for valid, trajectory in zip(self.valid_tag, self.points):
            if not valid:
                trajectory.clear()
        return self.points


class PFlowEstimatorLK:
    def __init__(self, hei, wid, win_rad=15, flag_tensor=True):
        self.lk_params = {'winSize': (win_rad, win_rad),
                          'maxLevel': 0,
                          'criteria': (cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 10, 0.03)}
        self.imsize = (hei, wid)
        self.flag_tensor = flag_tensor

        # Set old points
        xx = np.arange(0, wid).reshape(1, -1).repeat(hei, 0).astype(np.float32)
        yy = np.arange(0, hei).reshape(-1, 1).repeat(wid, 1).astype(np.float32)
        xy = np.stack([xx, yy], axis=2)
        self.cp_mat = cv2.resize(xy, (wid // 8, hei // 8), interpolation=cv2.INTER_LINEAR)
        self.p0 = self.cp_mat.reshape(-1, 2)

        self.thd_set = {'y': 1.0, 'bk': 0.5, 'err': 100.0}

    def set_thd(self, **kwargs):
        for key in kwargs:
            self.thd_set[key] = kwargs[key]

    def _estimate_dn8_np(self, src_img, dst_img):
        p1, st1, err1 = cv2.calcOpticalFlowPyrLK(src_img, dst_img, self.p0, None, **self.lk_params)
        p0, st0, err0 = cv2.calcOpticalFlowPyrLK(dst_img, src_img, p1, None, **self.lk_params)

        # 0. Filter by st0
        st1[st0 == 0] = 0

        # 1. Filter by delta_y
        st1[np.abs(p1[:, 1] - self.p0[:, 1]) > self.thd_set['y']] = 0
        st1[np.abs(p1[:, 1] - p0[:, 1]) > self.thd_set['y']] = 0

        # 2. Filter by p0 & self.p0
        st1[np.abs(p0[:, 0] - self.p0[:, 0]) > self.thd_set['bk']] = 0

        # 3. Filter by err
        # st1[err1 > self.thd_set['err']] = 0
        # st1[err0 > self.thd_set['err']] = 0

        # Apply to x
        delta = p1 - self.p0
        delta_xx = delta[:, :1]
        delta_xx[st1 == 0] = 0.0
        return delta_xx, st1, err1

    def estimate_dn8(self, src_img, dst_img):
        if self.flag_tensor:
            batch, ch, hei, wid = src_img.shape
        else:
            batch, ch = 1, 1

        pf_mats = []
        st_mats = []
        for n in range(batch):
            if self.flag_tensor:
                delta_xx, st, err = self._estimate_dn8_np(t2a(src_img[n] * 255.0).astype(np.uint8),
                                                          t2a(dst_img[n] * 255.0).astype(np.uint8))
            else:
                delta_xx, st, err = self._estimate_dn8_np(src_img, dst_img)
            pf_mat = delta_xx.reshape(self.cp_mat.shape[:2])
            st_mat = st.reshape(self.cp_mat.shape[:2])
            pf_mats.append(a2t(pf_mat))
            st_mats.append(a2t(st_mat))

        if self.flag_tensor:
            return torch.stack(pf_mats, dim=0).to(src_img.device), torch.stack(st_mats, dim=0).to(src_img.device)
        else:
            return pf_mats[0], st_mats[0]

    # def __call__(self, src_img, dst_img):
    #     hei, wid = self.imsize
    #     p1, st, err = cv2.calcOpticalFlowPyrLK(src_img, dst_img, self.p0, None, **self.lk_params)
    #
    #     delta = p1 - self.p0
    #
    #     # y thed
    #     delta_yy = delta[:, 1]
    #     st[np.abs(delta_yy) > self.thd_set['y']] = 0
    #
    #     # Apply to x
    #     delta_xx = delta[:, :1]
    #     delta_xx[st == 0] = 0.0
    #
    #     pf_mat = delta_xx.reshape(self.cp_mat.shape[:2])
    #     pf_mat_up = cv2.resize(pf_mat, (wid, hei), interpolation=cv2.INTER_LINEAR)
    #
    #     st_up = cv2.resize(st.reshape(pf_mat.shape), (wid, hei), interpolation=cv2.INTER_NEAREST)
    #     err_up = cv2.resize(err.reshape(pf_mat.shape), (wid, hei), interpolation=cv2.INTER_NEAREST)
    #
    #     return pf_mat_up, st_up, err_up


class MPFlowEstimator:
    """
    Flow type:
    [x^t-T+1, ..., x^t-1, x^t, idx, y, L]
    """

    def __init__(self, temp_win, sig2_max=1024.0, device='cpu'):
        self.T = temp_win
        self.sig2_max = sig2_max
        self.id_generator = ConIdGenerator()
        self.w_rad = 7
        self.h_rad = 1
        self.device = device
        kernel = torch.zeros(1, 1, 2 * self.h_rad + 1, 2 * self.w_rad + 1)
        for dh in range(-self.h_rad, self.h_rad + 1, 1):
            for dw in range(-self.w_rad, self.w_rad + 1, 1):
                h, w = dh + self.h_rad, dw + self.w_rad
                dist = dh ** 2 + dw ** 2
                norm_alpha = (self.h_rad ** 2 + self.w_rad ** 2) / 10
                kernel[0, 0, h, w] = np.exp(-dist / norm_alpha)
        self.kernel = kernel.to(device)
        self.imsize = None

    def reset(self):
        self.id_generator.reset()

    def _find_nearest_point(self, mask_center, idx_map_lst):
        hei, wid = self.imsize

        def get_nearest(src_idx_map):
            src_idx_map = src_idx_map.unsqueeze(0).unsqueeze(1).float()

            src_one_map = src_idx_map.clone()
            src_one_map[src_one_map > 0] = 1.0

            one_unfold = F.unfold(src_one_map, kernel_size=self.kernel.shape[2:4], padding=(self.h_rad, self.w_rad))
            one_unfold = one_unfold.reshape(1, -1, hei, wid)
            kernel_1d = self.kernel.reshape(1, -1, 1, 1)
            _, ref_pos_mat = torch.max(one_unfold * kernel_1d, dim=1, keepdim=True)

            idx_unfold = F.unfold(src_idx_map, kernel_size=self.kernel.shape[2:4], padding=(self.h_rad, self.w_rad))
            idx_unfold = idx_unfold.reshape(1, -1, hei, wid)
            idx_nearest = torch.gather(idx_unfold, dim=1, index=ref_pos_mat).squeeze()
            return idx_nearest

        idx_nearest_now = get_nearest(idx_map_lst)
        idx_nearest_now[mask_center == 0] = 0

        # Filter out unique
        _, x_coord, y_coord = self._map2dot(mask_center)
        id_now = torch.arange(0, x_coord.shape[0]).to(self.device)
        idx_map_now = self._dot2map(torch.stack([id_now, x_coord, y_coord], dim=1))

        nearest_now2lst = get_nearest(idx_map_now)
        nearest_now2lst[idx_map_lst == 0] = 0
        nearest_back = get_nearest(nearest_now2lst)
        mask_invalid = (nearest_back != idx_map_now)

        idx_nearest_now[mask_invalid] = 0
        return idx_nearest_now

    def _map2dot(self, idx_map):
        idx_map = idx_map.squeeze()
        y_coord, x_coord = torch.where(idx_map > 0)
        value = idx_map[y_coord.long(), x_coord.long()]
        return value, x_coord, y_coord

    def _dot2map(self, dot_coord):
        if dot_coord.shape[1] == 3:
            id_set, x_coord, y_coord = torch.chunk(dot_coord, chunks=3, dim=1)
        elif dot_coord.shape[1] == 2:
            x_coord, y_coord = torch.chunk(dot_coord, chunks=2, dim=1)
            id_set = torch.ones_like(x_coord)
        else:
            return
        dot_mat = torch.zeros(self.imsize).to(self.device)
        dot_mat = dot_mat.index_put(indices=[y_coord.long(), x_coord.long()], values=id_set.float())
        return dot_mat

    def run(self, mask_centers, distribution=None):
        """
        mask_centers: [T, 1, H, W]
        distribution: [Kc', 5]; idx, x^t-T, y^t-T, mu, sig2  需要将上一帧接过来；同时有一个初始化的操作。
            mu: 随机；sig: 设置一个最大值
        """

        try:

            self.imsize = mask_centers[0].squeeze().shape

            res_list = []
            for i in range(self.T):
                mask_centers[i] = mask_centers[i].to(self.device)
                _, x_coord, y_coord = self._map2dot(mask_centers[i])

                if distribution is None and i == 0:
                    idx_set = self.id_generator.get_new_tensor(x_coord.shape[0]).float()
                    idx_set = idx_set.to(self.device)

                else:
                    last_dot_set = res_list[-1] if i > 0 else distribution[:, :3]  # [Kc', 3]; idx, x^t-T, y^t-T
                    valid_dot, = torch.where(last_dot_set[:, 1] >= 0)
                    idx_mat_lst = self._dot2map(last_dot_set[valid_dot, :])
                    idx_mat = self._find_nearest_point(mask_centers[i].squeeze(), idx_mat_lst)
                    idx_set = idx_mat[y_coord, x_coord]
                    new_pos, = torch.where(idx_set <= 0)
                    idx_set[new_pos] = self.id_generator.get_new_tensor(new_pos.shape[0]).float().to(self.device)

                dot_set = torch.stack([idx_set, x_coord, y_coord], dim=1)  # [Kc', 3]
                res_list.append(dot_set)

            min_val = int(res_list[0][:, 0].min().item())
            max_val = max([int(res_list[t][:, 0].max().item()) for t in range(self.T)]) + 1
            # min_val, max_val = int(res_list[0][:, 0].min().item()), int(res_list[-1][:, 0].max().item()) + 2
            flow_set = -torch.ones([self.T, 2, max_val - min_val + 1]).to(self.device)  # [T, 2, Kc]; 0 -> invalid
            for t in range(self.T):
                idx = res_list[t][:, 0].long() - min_val + 1
                flow_set[t, 0, idx] = res_list[t][:, 1]
                flow_set[t, 1, idx] = res_list[t][:, 2]
            # flow_set = flow_set.long()

            new_distribution = torch.zeros([max_val - min_val + 1, 5]).to(self.device)  # [Kc, 3]
            mask_match = torch.zeros(max_val - min_val + 1).to(self.device)
            new_distribution[:, 0] = torch.arange(min_val - 1, max_val)  # idx
            new_distribution[:, 1] = flow_set[-1, 0, :]  # x^t
            new_distribution[:, 2] = flow_set[-1, 1, :]  # y^t
            if distribution is None:
                mask_match[:] = 0.0
            else:
                idx_lst = distribution[:, 0].long() - min_val + 1
                idx_lst[idx_lst < 0] = 0
                mask_match[idx_lst] = 1.0
                new_distribution[idx_lst, 3] = distribution[:, 3]
                new_distribution[idx_lst, 4] = distribution[:, 4]
            mask_match[0] = 0.0
            mask_match = mask_match.view(-1, 1)  # [Kc, 1]

            # Init new
            mu_init = torch.ones_like(mask_match).to(self.device) * self.imsize[1] / 2.0
            sig2_init = torch.ones_like(mask_match).to(self.device) * self.sig2_max
            init_set = torch.cat([mu_init, sig2_init], dim=1)  # [Kc, 2]
            new_distribution[:, 3:5] *= mask_match
            new_distribution[:, 3:5] += (1.0 - mask_match) * init_set
            new_distribution[0, :] = torch.Tensor([0.0, -1.0, -1.0, self.imsize[1] / 2.0, self.sig2_max]).to(self.device)

        except RuntimeError as e:
            print(e)
            raise e

        return flow_set, new_distribution

    # def to_tensor(self, flow_set):
    #     # flow_set: [x^t-T+1, ... x^t, y, idx]; Add additional zero line on first N
    #     # out_tensor: [T, N, 2]
    #     out_tensor = torch.zeros([self.T, flow_set.shape[0], 2]).to(flow_set.device)
    #     for t in range(self.T):
    #         out_tensor[t, :, 0] = flow_set[:, t]
    #         out_tensor[t, :, 1] = flow_set[:, self.T]
    #         # out_tensor[t, out_tensor[t, :, 0] < 0, 1] = -1
    #     zero_row = torch.zeros([self.T, 1, 2]).to(flow_set.device)  # [T, 1, 2]
    #     return torch.cat([zero_row, out_tensor], dim=1)

# def main():
#     data_path = Path(r'C:\SLDataSet\20211118r\20211118_151321')
#     frm_num = len(list((data_path / 'img').glob('*.png')))
#     temp_win = 8
#     flow_estimator = MPFlowEstimator(temp_win, device='cuda:0')
#     distribution = None
#
#     for frm_start in range(0, frm_num, temp_win):
#         mask_centers = [imload(data_path / 'mask_center' / f'mask_{frm_start + i}.png') for i in range(temp_win)]
#         last_frm_flow, distribution = flow_estimator.run(mask_centers, distribution)
#         print(distribution[1, :])
#         pass
#
#     pass
#
#
# if __name__ == '__main__':
#     main()
