# -*- coding: utf-8 -*-

# @Time:      2021/3/3 20:08
# @Author:    qiao
# @Email:     rukunqiao@outlook.com
# @File:      learning.py
# @Software:  PyCharm
# @Description:
#   None

# - Package Imports - #
import numpy as np
import time
from collections import OrderedDict
import torch
import cv2

from .dataio import t2a, a2t


# - Coding Part - #
class StopWatch(object):
    def __init__(self):
        self.timings = OrderedDict()
        self.starts = {}
        self.current_name = None
        self.sync = True
        # self.current_profile = None
        # self.current_prof = None
        # self.current_name = None

    def record(self, name, sync=True):
        self.current_name = name
        self.sync = sync
        return self

    def __enter__(self):
        self.start(self.current_name)
        pass

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.sync:
            torch.cuda.synchronize()
        self.stop(self.current_name)

    def start(self, name):
        self.starts[name] = time.time()

    def stop(self, name):
        if name not in self.timings:
            self.timings[name] = []
        self.timings[name].append(time.time() - self.starts[name])

    def get(self, name=None, reduce=np.sum):
        if name is not None:
            return reduce(self.timings[name])
        else:
            ret = {}
            for k in self.timings:
                ret[k] = reduce(self.timings[k])
            return ret

    def __repr__(self):
        return ', '.join([f'{k}: {v:.2f}s' for k, v in self.get().items()])

    def __str__(self):
        return ', '.join([f'{k}: {v:.2f}s' for k, v in self.get().items()])


class TimeKeeper:
    def __init__(self):
        self.start_time = time.time()

    def __str__(self):
        left_time = time.time() - self.start_time
        hour = int(left_time // 3600)
        left_time -= hour * 3600
        minute = int(left_time // 60)
        left_time -= minute * 60
        second = int(left_time)
        return f'{hour:02d}h:{minute:02d}m:{second:02d}s'


class AverageMeter:
    """Computes and stores the average and current value."""
    def __init__(self, name='DEFAULT'):
        self.name = name
        self.avg, self.sum, self.count = 0, 0, 0

    def update(self, val, n=1):
        if isinstance(val, torch.Tensor):
            val = val.detach().cpu().mean().item()
        self.sum += val * n
        self.count += n
        self.avg = self.sum / self.count

    def get(self):
        avg = self.avg
        return avg

    def clear(self):
        self.avg, self.sum, self.count = 0, 0, 0

    def __str__(self):
        return f'[{self.name}]{self.avg:.2f}-({self.count})'


class EpochMeter:
    """Iter average & epoch average is stored"""
    def __init__(self, name='DEFAULT'):
        self.name = name
        self.iter = AverageMeter(name)
        self.epoch = AverageMeter(name)

    def update(self, val, n=1):
        self.iter.update(val, n)
        self.epoch.update(val, n)

    def get_iter(self):
        return self.iter.get()

    def clear_iter(self):
        self.iter.clear()

    def get_epoch(self):
        return self.epoch.get()

    def clear_epoch(self):
        self.iter.clear()
        self.epoch.clear()

    def __str__(self):
        return f'local: {self.iter}; epoch: {self.epoch}.'


class VisualFactory:
    def __init__(self):
        pass

    @staticmethod
    def _crop_shape(img):
        assert len(img.shape) == 2 or len(img.shape) == 3 or len(img.shape) == 4
        if len(img.shape) == 2:
            return img.unsqueeze(0)
        elif len(img.shape) == 3:
            return img
        else:
            return img[0]

    @staticmethod
    def img_visual(img_mat, mask_mat=None, max_val=None):
        img_mat = VisualFactory._crop_shape(img_mat)
        if mask_mat is not None:
            mask_mat = VisualFactory._crop_shape(mask_mat)
            img_mat *= mask_mat
        if max_val is not None:
            if torch.min(img_mat).item() < 0:
                img_mat = img_mat / (2 * max_val) + 0.5
            else:
                img_mat = img_mat / max_val
            img_mat = torch.clamp(img_mat, 0, 1.0)
        channel = img_mat.shape[0]
        if channel == 1:
            img_mat = img_mat.repeat(3, 1, 1)
        if mask_mat is not None:
            img_mat[mask_mat.repeat(3, 1, 1) == 0] = 0
        return img_mat

    @staticmethod
    def disp_visual(disp_mat, mask_mat=None, range_val=None, color_map=cv2.COLORMAP_JET):
        """Convert disp mat into color mat."""
        disp_mat = VisualFactory._crop_shape(disp_mat)
        if mask_mat is not None:
            mask_mat = VisualFactory._crop_shape(mask_mat)
            disp_mat = disp_mat * mask_mat
        if range_val is not None:
            min_val, max_val = range_val
            disp_mat = (disp_mat - min_val) / (max_val - min_val)
            disp_mat = torch.clamp(disp_mat, 0.0, 1.0)
        disp_rgb_u8 = cv2.applyColorMap((t2a(disp_mat) * 255.0).astype(np.uint8), color_map)
        disp_rgb_u8 = cv2.cvtColor(disp_rgb_u8, cv2.COLOR_BGR2RGB)
        disp_rgb = disp_rgb_u8.astype(np.float32) / 255.0
        color_mat = a2t(disp_rgb).to(disp_mat.device)
        if mask_mat is not None:
            color_mat[mask_mat.repeat(3, 1, 1) == 0] = 0
        return color_mat

    @staticmethod
    def norm_visual(disp_mat, mask_mat=None, focal_length=500.0):
        """Visualize normal"""
        disp_mat = VisualFactory._crop_shape(disp_mat)
        if mask_mat is not None:
            mask_mat = VisualFactory._crop_shape(mask_mat)
            disp_mat = disp_mat * mask_mat

        # Calculate dX, dY
        dX, dY = t2a(disp_mat), t2a(disp_mat)
        dX[:, 1:] -= dX[:, :-1]
        dX[:, 0] = 0
        dY[1:, :] -= dY[:-1, :]
        dY[0, :] = 0

        # Normal vec: (dX, dY, -1)
        normal_len = np.sqrt(dX ** 2 + dY ** 2 + 1.0 / focal_length)
        ch_red = (dX / normal_len) / 2.0 + 0.5
        ch_grn = (dY / normal_len) / 2.0 + 0.5
        ch_blu = (1 / focal_length / normal_len) / 2.0 + 0.5
        disp_show = np.stack([ch_red, ch_grn, ch_blu], axis=2)
        disp_rgb = a2t(disp_show).to(disp_mat.device)
        if mask_mat is not None:
            disp_rgb[mask_mat.repeat(3, 1, 1) == 0] = 0
        return disp_rgb

    @staticmethod
    def flow_visual(flow_mat, mask_mat=None, max_val=None):
        flow_mat = VisualFactory._crop_shape(flow_mat)
        max_val = max_val if max_val is not None else torch.max(torch.abs(flow_mat)).item()
        if mask_mat is not None:
            mask_mat = VisualFactory._crop_shape(mask_mat)
            flow_mat *= mask_mat
        color_mat = torch.ones(3, *flow_mat.shape[1:]).to(flow_mat.device)  # [3, H, W]
        color_mat[0] = 1 - flow_mat / max_val
        color_mat[1] = 1 - abs(flow_mat / max_val)
        color_mat[2] = 1 + flow_mat / max_val
        color_mat = torch.clamp(color_mat, 0.0, 1.0)
        if mask_mat is not None:
            color_mat[mask_mat.repeat(3, 1, 1) == 0] = 0
        return color_mat

    @staticmethod
    def opt_visual(flow_mat, mask_mat=None, max_val=10.0):
        flow_mat = VisualFactory._crop_shape(flow_mat)
        if mask_mat is not None:
            mask_mat = VisualFactory._crop_shape(mask_mat)
            flow_mat *= mask_mat
        flow_np = t2a(flow_mat) / max_val
        mag, ang = cv2.cartToPolar(flow_np[:, :, 0], flow_np[:, :, 1])
        hsv_mat = np.zeros([*flow_np.shape[:2], 3], dtype=np.uint8)
        hsv_mat[:, :, 0] = ang * 180.0 / np.pi / 2.0
        hsv_mat[:, :, 2] = 255
        hsv_mat[:, :, 1] = mag / 1.5 * 255
        color_mat = cv2.cvtColor(hsv_mat, cv2.COLOR_HSV2BGR)
        color_mat = a2t(color_mat.astype(np.float32) / 255.0).to(flow_mat.device)
        if mask_mat is not None:
            color_mat[mask_mat.repeat(3, 1, 1) == 0] = 0
        return color_mat

    @staticmethod
    def err_visual(err_mat, mask_mat=None, max_val=None, color_map=cv2.COLORMAP_SUMMER):
        err_mat = VisualFactory._crop_shape(err_mat)
        if mask_mat is not None:
            mask_mat = VisualFactory._crop_shape(mask_mat)
            err_mat *= mask_mat
        err_mat = torch.abs(err_mat) / max_val
        err_mat = torch.clamp(err_mat, 0.0, 1.0)
        err_rgb = cv2.applyColorMap((t2a(err_mat) * 255.0).astype(np.uint8), color_map)
        err_rgb = cv2.cvtColor(err_rgb, cv2.COLOR_BGR2RGB)
        color_mat = a2t(err_rgb.astype(np.float32) / 255.0).to(err_mat.device)
        if mask_mat is not None:
            color_mat[mask_mat.repeat(3, 1, 1) == 0] = 0
        return color_mat

    @staticmethod
    def warp_visual(img1, img2_warped, img2=None, mask_mat=None, max_val=None):
        img1_viz = VisualFactory.img_visual(img1, mask_mat, max_val)[:1]
        img2_warped_viz = VisualFactory.img_visual(img2_warped, mask_mat, max_val)[:1]
        img2_viz = torch.zeros_like(img1_viz) if img2 is None else VisualFactory.img_visual(img2, mask_mat, max_val)[:1]
        warp_viz = torch.cat([img1_viz, img2_viz, img2_warped_viz], dim=0)
        if mask_mat is not None:
            warp_viz[mask_mat.repeat(3, 1, 1) == 0] = 0
        return warp_viz

    @staticmethod
    def img_concat(img_list, hei_num, wid_num, transpose=False):
        """Concat all image in img_list. RowMajor."""
        h_dim, w_dim = 1, 2
        if transpose:
            h_dim, w_dim = 2, 1

        h_stack = []
        for h in range(0, hei_num):
            idx_lf = h * wid_num
            idx_rt = min((h + 1) * wid_num, len(img_list))
            # Check max_len
            img_part = img_list[idx_lf:idx_rt]
            if len(img_part) < wid_num:
                img_part += [torch.zeros_like(img_list[0])] * (wid_num - len(img_part))
            h_stack.append(torch.cat(img_part, dim=w_dim))
        return torch.cat(h_stack, dim=h_dim)
