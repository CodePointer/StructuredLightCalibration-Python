# -*- coding: utf-8 -*-

# @Time:      2021/2/25 13:57
# @Author:    qiao
# @Email:     rukunqiao@outlook.com
# @File:      dataio.py
# @Software:  PyCharm
# @Description:
#   None

# - Package Imports - #
import torch
import cv2
import numpy as np
import pathlib
import imageio
import re


# - Coding Part - #
def sprint(output, silence=False, **kwargs):
    if not silence:
        print(output, kwargs)


def str2tuple(input_string, item_type=float):
    """.ini file processing function."""
    return tuple([item_type(x.strip()) for x in input_string.split(',')])


def str2array(input_string, array_type=np.float32, array_size=None):
    """.ini file processing function."""
    output_array = np.array(str2tuple(input_string, array_type), dtype=array_type)
    if array_size is not None:
        output_array = output_array.reshape(array_size)
    return output_array


def a2t(in_array, permute=True):
    """np.ndarray -> torch.Tensor.
        Output shape:
            [H, W] -> [1, H, W]
            [H, W, C] -> [C, H, W] (permute = True)
                      -> [H, W, C] (permute = False)
            other shape -> same
    """
    if isinstance(in_array, torch.Tensor):
        return in_array
    out_tensor = torch.from_numpy(in_array)
    if len(out_tensor.shape) == 2:
        return out_tensor.unsqueeze(0)
    elif len(out_tensor.shape) == 3:
        if permute:
            return out_tensor.permute(2, 0, 1)
        else:
            return out_tensor
    else:
        return out_tensor


def t2a(in_tensor, permute=True):
    """torch.Tensor -> np.ndarray.
        Output shape:
            [1, H, W] -> [H, W]
            [C, H, W] -> [H, W, C] (permute = True)
                      -> [C, H, W] (permute = False)
            other shape -> same
    """
    if isinstance(in_tensor, np.ndarray):
        return in_tensor
    out_tensor = in_tensor.detach().cpu()
    if len(out_tensor.shape) == 3:
        if out_tensor.shape[0] == 1:
            return out_tensor.squeeze(0).numpy()
        else:
            if permute:
                return out_tensor.permute(1, 2, 0).numpy()
            else:
                return out_tensor.numpy()
    else:
        return out_tensor.numpy()


def subfolders(folder):
    if folder is None:
        return None
    if not isinstance(folder, pathlib.Path):
        path = pathlib.Path(folder)
    folders = []
    for path in folder.glob('*'):
        if path.is_dir():
            folders.append(path)
    return sorted(folders)


def imload(path, scale=255.0, bias=0.0, flag_tensor=True):
    """Load image with default type."""
    img = cv2.imread(str(path), cv2.IMREAD_UNCHANGED)
    if img is None:
        raise IOError(f'Failed to read file: {path}')
    img = (img.astype(np.float32) - bias) / scale
    if flag_tensor:
        img = a2t(img)
    return img


def imsave(path, img, scale=255.0, bias=0.0, img_type=np.uint8, mkdir=False):
    """Save image."""
    img_copy = t2a(img).copy()
    img_copy = img_copy.astype(np.float32) * scale + bias
    # Check folder
    if mkdir:
        pathlib.Path(path).parent.mkdir(parents=True, exist_ok=True)
    cv2.imwrite(str(path), img_copy.astype(img_type))


def imviz(img, name='DEFAULT', wait=0, normalize=None):
    """Visualize image. Accept normalization function for visualize."""
    img_copy = t2a(img).copy()
    if img_copy.dtype == np.uint8:
        img_copy = img_copy.astype(np.float32) / 255.0
    if isinstance(normalize, list):
        min_val, max_val = 0, 255
        if len(normalize) == 0:
            min_val, max_val = np.min(img_copy), np.max(img_copy)
        elif len(normalize) == 2:
            min_val, max_val = normalize
        else:
            raise ValueError(f"Normalize length is not valid: {len(normalize)}")
        img_copy = (img_copy - min_val) / (max_val - min_val)
        img_copy = np.clip(img_copy, 0, 1.0)
    cv2.imshow(name, (img_copy * 255.0).astype(np.uint8))
    return cv2.waitKey(wait)


class GifWriter:
    def __init__(self, gif_name, roi=None, fps=10, scale=1.0):
        self.writer = imageio.get_writer(str(gif_name), mode='I', fps=fps)
        self.roi = roi
        self.scale = scale

    def __del__(self):
        if not self.writer.closed:
            self.writer.close()

    @staticmethod
    def _get_key(folder):
        name = folder.name
        result = re.findall(r'\d+', name)
        return int(result[0])

    def run_folder(self, folder, interval=1, max_frm=None, set_num=False):
        img_list = sorted(list(folder.glob('*.png')), key=self._get_key)
        max_frm = len(img_list) if max_frm is None else max_frm
        for i in range(1, max_frm, interval):
            img = cv2.imread(str(img_list[i]), cv2.IMREAD_UNCHANGED)
            if set_num:
                img = cv2.putText(img, str(i), (20, 40), cv2.FONT_HERSHEY_SIMPLEX,
                                  1, (0, 0, 255), 2)
                # imviz(img, 'img', 0)
            self.append(img)
        self.write()

    def append(self, img):
        if len(img.shape) >= 3:
            img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        else:
            img = cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)
        if self.roi is not None:
            ws, we, hs, he = self.roi
            img = img[hs:he, ws:we, :]

        hei, wid, _ = img.shape
        hei_s, wid_s = int(hei * self.scale), int(wid * self.scale)
        img = cv2.resize(img, (wid_s, hei_s))

        self.writer.append_data(img)

    def write(self):
        self.writer.close()
